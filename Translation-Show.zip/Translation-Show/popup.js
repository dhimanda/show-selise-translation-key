const toggle = document.getElementById("toggle");

async function init() {
  const { blocked } = await chrome.storage.local.get({ blocked: false });
  toggle.checked = !!blocked;
}

toggle.addEventListener("change", () => {
  chrome.runtime.sendMessage({ blocked: toggle.checked }, (res) => {
    if (!res?.ok) {
      console.error("Toggle failed");
      return;
    }

    // Reload current active tab
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) chrome.tabs.reload(tabs[0].id);
    });
  });
});

init();
