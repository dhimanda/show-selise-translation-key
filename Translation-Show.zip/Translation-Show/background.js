const RULE_ID = 1;

const createBlockRule = () => ({
  id: RULE_ID,
  priority: 1,
  action: { type: "block" },
  condition: {
    regexFilter: "^https?://[^/]+/api/uilm/v[0-9]+/LanguageManager/Query/GetUilmFile.*",
    resourceTypes: ["xmlhttprequest"]
  }
});

async function applyBlockRule() {
  await chrome.declarativeNetRequest.updateDynamicRules({
    addRules: [createBlockRule()],
    removeRuleIds: []
  });
}

async function removeBlockRule() {
  await chrome.declarativeNetRequest.updateDynamicRules({
    addRules: [],
    removeRuleIds: [RULE_ID]
  });
}

chrome.runtime.onInstalled.addListener(async () => {
  const { blocked } = await chrome.storage.local.get({ blocked: false });
  if (blocked) applyBlockRule();
  else removeBlockRule();
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (typeof msg.blocked === "boolean") {
    chrome.storage.local.set({ blocked: msg.blocked }).then(async () => {
      if (msg.blocked) await applyBlockRule();
      else await removeBlockRule();
      sendResponse({ ok: true });
    });
    return true;
  }
});
