const RULE_ID_1 = 1;
const RULE_ID_2 = 2;
const RULE_ID_3 = 3;

const createBlockRules = () => [
  {
    id: RULE_ID_1,
    priority: 1,
    action: { type: "block" },
    condition: {
      regexFilter: "^https?://[^/]+/api/uilm/v[0-9]+/LanguageManager/Query/GetUilmFile.*",
      resourceTypes: ["xmlhttprequest"]
    }
  },
  {
    id: RULE_ID_2,
    priority: 1,
    action: { type: "block" },
    condition: {
      regexFilter: "^https?://[^/]+/uilm/v[0-9]+/Key/GetUilmFile.*",
      resourceTypes: ["xmlhttprequest"]
    }
  },
  {
    id: RULE_ID_3,
    priority: 1,
    action: { type: "block" },
    condition: {
      regexFilter: "^https?://[^/]+.*BlocksConfiguration/UILM/GetUilmFile.*",
      resourceTypes: ["xmlhttprequest"]
    }
  }
];

async function applyBlockRule() {
  await chrome.declarativeNetRequest.updateDynamicRules({
    addRules: createBlockRules(),
    removeRuleIds: []
  });
}

async function removeBlockRule() {
  await chrome.declarativeNetRequest.updateDynamicRules({
    addRules: [],
    removeRuleIds: [RULE_ID_1, RULE_ID_2, RULE_ID_3]
  });
}

chrome.runtime.onInstalled.addListener(async () => {
  const { blocked } = await chrome.storage.local.get({ blocked: false });
  if (blocked) applyBlockRule();
  else removeBlockRule();
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (typeof msg.blocked === "boolean") {
    chrome.storage.local.set({ blocked: msg.blocked }).then(async () => {
      if (msg.blocked) await applyBlockRule();
      else await removeBlockRule();
      sendResponse({ ok: true });
    });
    return true;
  }
});
